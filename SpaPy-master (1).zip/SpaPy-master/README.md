# SpaPy
Fast and fun geospatial library based on open source software.
A website with installation instructions and tutorials is available at: http://jim.reclaim.hosting/SpaPy
