############################################################################
# Classes and functions for performing topographic functions on 
# spatially referenced raster data.
# 
############################################################################

import os
import numbers
import math

import numpy
import scipy
import ogr
import scipy.ndimage
from SpaRasters import SpaDatasetRaster
from osgeo import osr

import SpaPy

from SpaRasterMath import *


###############################################################################
# Class definition
###############################################################################
class SpaTopoTools(SpaPy.SpaTransform):
    #adapted from https://www.neonscience.org/create-hillshade-py
    def __init__(self):
        super().__init__()


    def Hillshade(self,Input1,azimuth=315,altitude=45):

        """
        Creates a hillshade layer from a digital elevation model by determining hypothetical illumination
        values for each cell based on provided azimuth and altitude values

        Parameters:
        	Input1: An SpaDatasetRaster object OR a string representing the path to the raster file

        Return:
        	A SpaDatasetRaster object depicting hillshade
        """

        NewDataset=SpaDatasetRaster()
        NewDataset.CopyPropertiesButNotData(Input1)

        array=Input1.TheBands[0]
        azimuth = 360.0 - azimuth

        x, y = numpy.gradient(array)
        slope = numpy.pi/2. - numpy.arctan(numpy.sqrt(x*x + y*y))
        aspect = numpy.arctan2(-x, y)
        azimuthrad = azimuth*numpy.pi/180.
        altituderad = altitude*numpy.pi/180.

        shaded = numpy.sin(altituderad)*numpy.sin(slope) + numpy.cos(altituderad)*numpy.cos(slope)*numpy.cos((azimuthrad - numpy.pi/2.) - aspect)
        shaded = 255*(shaded + 1)/2

        NewDataset.TheBands=[shaded]
        return(NewDataset)

    def Slope(self,Input1):
        """
        Creates a slope layer from a digital elevation model by calculating the steepness of each cell
        (returns with a value between 0-90 degrees)

        Parameters:
        	Input1: An SpaDatasetRaster object OR a string representing the path to the raster file

        Return:
        	A SpaDatasetRaster object depicting slope
        """

        NewDataset=SpaDatasetRaster()
        NewDataset.CopyPropertiesButNotData(Input1)

        TheBand=Input1.TheBands[0]
        x,y = numpy.gradient(TheBand)
        slope=numpy.pi/2. - numpy.arctan(numpy.sqrt(x*x +y*y))

        NewDataset.TheBands = [slope]
        return(NewDataset)

    def Aspect(self,Input1):
        """
        Creates an aspect layer from a digital elevation model by identifing the compass
        direction that the downhill slope faces for each location (returns with a value between 0-360 degrees)


        Parameters:
        	Input1: An SpaDatasetRaster object OR a string representing the path to the raster file

        Return:
        	A SpaDatasetRaster object depicting aspect	
        """

        NewDataset=SpaDatasetRaster()
        NewDataset.CopyPropertiesButNotData(Input1)

        TheBand=Input1.TheBands[0]
        x,y = numpy.gradient(TheBand)
        aspect = numpy.arctan2(-x, y)

        NewDataset.TheBands=[aspect]
        return(NewDataset)

###############################################################################
# One line functions
###############################################################################
def Hillshade(Input1):
    """
    Creates a hillshade from a digital elevation model by determining hypothetical illumination
    values for each cell based on given azimuth and altitude values

    Parameters:
    	Input1: An SpaDatasetRaster object OR a string representing the path to the raster file

    Return:
    	A SpaDatasetRaster object
    """

    Input1=SpaPy.GetInput(Input1)
    TheTopoTools=SpaTopoTools()
    return(TheTopoTools.Hillshade(Input1))

def Slope(Input1):
    """
    Creates a slope layer from a digital elevation model by calculating the steepness of each cell
    (returns with a value between 0-90 degrees)

    Parameters:
    Input1: An SpaDatasetRaster object OR a string representing the path to the raster file

    Return:
	A SpaDatasetRaster object depicting slope
    """

    Input1=SpaPy.GetInput(Input1)
    TheTopoTools=SpaTopoTools()
    return(TheTopoTools.Slope(Input1))


def Aspect(Input1):
    """
    Creates an aspect layer from a digital elevation model by identifing the compass
    direction that the downhill slope faces for each location (returns with a value between 0-360 degrees)

    Parameters:
    	Input1: An SpaDatasetRaster object OR a string representing the path to the raster file

    Return:
    	A SpaDatasetRaster object depicting aspect	
    """	
    Input1=SpaPy.GetInput(Input1)
    TheTopoTools=SpaTopoTools()
    return(TheTopoTools.Aspect(Input1))

"""
***************************************************************************
 Copyright (C) 2020, Humboldt State University, Jim Graham

This program is free software: you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software  Foundation, either version 3 of the License, or (at your
option) any later  version.

This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General
Public License for more details.

A copy of the GNU General Public License is available at
<http://www.gnu.org/licenses/>.
***************************************************************************
"""