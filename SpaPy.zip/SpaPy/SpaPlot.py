############################################################################
# Code to make it easy to plot a variety of spatial data with MatPlotLib.
############################################################################

from matplotlib import pyplot as pyplot

import SpaPy

############################################################################
# Globals
############################################################################

class SpaPlot:
	""" 
	Class to plot spatial data in a matplotlib
	"""
	def __init__(self):
		# below are the properties that make up a shapefile using Fiona for reading and writing from and to shapefiles
		self.TheGeometries=[]
		self.TheAttributes=[]

	############################################################################
	def PlotCoords(self,TheCoords):
		"""
		Plots (x,y) coordinates 
		
		Parameters:
			TheCoords: 
				coordinate data 
		Returns:
			none
		"""
		Xs,Ys=SpaPy.GetXYsFromCoords(TheCoords)
		
		if (len(Xs)>2):
			pyplot.plot(Xs,Ys, color='#ff0000', alpha=0.7,linewidth=3, solid_capstyle='round', zorder=2)

	def PlotPolygon(self,ThePolygon):
		"""
		Plots polygon data
		
		Parameters:
			ThePolygon: 
				Polygon geometry
		Returns:
			none
		"""		
		Coords=ThePolygon.exterior.coords
		self.PlotCoords(Coords)
		
	def PlotGeometry(self,TheGeometry):
		"""
		Plots geometry data
		
		Parameters:
			TheGeometry: 
				object geometry
		Returns:
			none
		"""				
		if (TheGeometry!=None):
			# take the appropriate action based on the type of geometry
			TheType=TheGeometry.geom_type
			
			if (TheType=="Polygon"):
				self.PlotPolygon(TheGeometry)
			#if (TheType=="Point"):
				#pyplot.scatter(CoordXs,CoordYs, color='#6699cc', marker='^')
				
			elif (TheType=="MultiPolygon"):
				for ThePolygon in TheGeometry:
					self.PlotPolygon(ThePolygon)
					
			elif (TheType=="GeometryCollection"): # collections are typically empty for shapefiles
				for TheSubGeometry in TheGeometry:
					self.PlotGeometry(TheSubGeometry)
					
			else:
				print("Unsupported Type: "+TheType)
		
	def Plot(self,TheDataset):
		"""
		Plot the specified dataset into the chart
		
		Parameters:
			TheDataset: 
				Insert dataset to be plotted
		Returns: None
		"""
		NumFeatures=TheDataset.GetNumFeatures()
		Index=0
		while (Index<NumFeatures):
			TheGeometry=TheDataset.GetGeometry(Index)
			
			self.PlotGeometry(TheGeometry)
			
			Index+=1

	def Show(self):
		"""
		Make the chart visible
		
		Parameters:
			none
		Returns:
			none
		"""
		pyplot.show()		

	############################################################################
	# Globals
	############################################################################
	
