###############################################################################################
# Seems like this should be part of SpaRasters
###############################################################################################
# 
import os
import numbers
import math
import inspect #not needed?

import gdal
import numpy
import scipy
import ogr
import scipy.ndimage
from osgeo import osr

import SpaPy

from SpaRasterMath import *

############################################################################################

def Polygonize(Input1):
    """ 
    Converts a raster to a polygon feature set.  Each contiguous area of the raster
    (i.e. ajoining pixels that have the same value) are grouped as one polygon.  

    Parameters:
    	An SpaDatasetRaster object OR a string representing the path to the raster file
    Returns:
    	A RasterDataset
    """	
    Input1=SpaPy.GetInput(Input1)
    return(Input1.Polygonize())