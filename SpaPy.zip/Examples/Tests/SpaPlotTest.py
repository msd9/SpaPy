############################################################################
# Test File for the Spatial (SP) libraries
############################################################################

# Open source spatial libraries
import shapely
from shapely import geometry

import sys  
sys.path.append("../../SpaPy") 

# SP Libraries
import SpaPlot
import SpaVectors
import SpaView
import SpaReferencing

############################################################################
# Globals
############################################################################
CountriesFilePath="../Data/ne_110m_admin_0_countries.shp"
InputFile=CountriesFilePath

OutputFolderPath="../Temp/"

############################################################################
# STLayerVector functions
############################################################################

#########################################################################
# Load the dataset into SpaDatasetVector object.

TheDataset=SpaVectors.SpaDatasetVector() #create a new layer

TheDataset.Load(CountriesFilePath) # load the contents of the layer

#########################################################################
# Plotting operations

if (True):
	ThePlotter=SpaPlot.SpaPlot()
	
	ThePlotter.Plot(TheDataset)
	
	ThePlotter.Show()

