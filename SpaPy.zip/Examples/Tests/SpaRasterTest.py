############################################################################
# Test File for the Spatial (SP) libraries
############################################################################

# Open source spatial libraries
import sys
sys.path.append("../../SpaPy")

# SP Libraries
import SpaPlot
import SpaView
import SPRasters
import SpaTopographicTransforms
import gdal

############################################################################
# Globals
############################################################################

RasterFilePath="../Data/test_raster.tif"

TempFolderPath="../Temp/"

#########################################################################
# Raster opterations
#########################################################################

TheDataset =SPRasters.SpaDatasetRaster()
TheDataset.Load(RasterFilePath)

print("____________________________________")
print("Loading Raster: "+RasterFilePath)

print(TheDataset.GetDriverNames())

print("Width in pixels: "+format(TheDataset.GetWidthInPixels()))

print("Height in pixels: "+format(TheDataset.GetHeightInPixels()))

print("Projection:".format(TheDataset.GetProjection()))

TheBounds=TheDataset.GetBounds()
print("TheBounds="+format(TheBounds))
Xmin,Ymax = TheDataset.XMin, TheDataset.YMax
print("TheXmin="+format(Xmin))
print("TheYmax="+format(Ymax))

TheBand=TheDataset.GetBandInfo(1) # band numbers start at 1
print("TheBandInfo="+format(TheBand))

# Run this function to execute tests
#######################################################################
# Get information on an existing raster and save it to a new name


if (True): #for toggling code on/off for debugging

	TheDataset =SPRasters.SpaDatasetRaster()
	TheDataset.Load(RasterFilePath)

	print("____________________________________")
	print("Loading Raster: "+RasterFilePath)

	print(TheDataset.GetDriverNames())

	print(TheDataset.GDALDataset.GetMetadata()) # empty

	print("Width in pixels: "+format(TheDataset.GetWidthInPixels()))

	print("Height in pixels: "+format(TheDataset.GetHeightInPixels()))

	print("Num Bands: "+format(TheDataset.GetNumBands()))

	print("Projection: "+format(TheDataset.GetProjection()))

	print("Resolution (x,y): "+format(TheDataset.GetResolution()))

	TheBounds=TheDataset.GetBounds()
	print("TheBounds (XMin,YMin,YMax,XMax): "+format(TheBounds))

	TheBandStats=TheDataset.GetBandInfo(1)
	print("TheBandStats="+format(TheBandStats))

	TheWKT=TheDataset.TheWKT
	print("TheWKT="+format(TheBandStats))

	#TheBand=TheDataset.GetBandAsArray(1)
	#print("TheBands: "+format(TheBand))

	TheDataset.Save(TempFolderPath+"CopiedRaster.tif")
#######################################################################
# Test writing out a new raster

if (True):
	WidthInPixels=100
	HeightInPixels=100

	TheDataset=SPRasters.SpaDatasetRaster()
	TheDataset.SetWidthInPixels(WidthInPixels)
	TheDataset.SetHeightInPixels(HeightInPixels)
	TheDataset.SetType(gdal.GDT_Float32)

	TheBands=TheDataset.AllocateArray()
	TheBands=TheBands[0]

	Row=0
	while (Row<HeightInPixels):
		Column=0
		while (Column<WidthInPixels):
			TheBands[Row][Column]=Column
			Column+=1
		Row+=1
	print(TheBands)

	TheDataset.SetUTM(10)
	TheDataset.SetNorthWestCorner(400000,4000000)
	TheDataset.SetResolution(30,30)
	TheDataset.Save(TempFolderPath+"NewRaster.tif")

#######################################################################
# Transform an existing raster

#Clone
if (True):
	TheDataset=SPRasters.SpaDatasetRaster()
	TheDataset.Load(RasterFilePath)
	NewDataset=TheDataset.Clone()
	NewDataset.Save(TempFolderPath+"ClonedRaster.tif")

#Polygonize


#Basic Math
if (True):
	NewDataset=SPRasters.Add(TheDataset,10)
	NewDataset.Save(TempFolderPath+"Raster_Add10.tif")


	NewDataset=SPRasters.Subtract(TheDataset,10)
	NewDataset.Save(TempFolderPath+"Raster_SUBTRACT10.tif")

	NewDataset=SPRasters.Multiply(TheDataset,10)
	NewDataset.Save(TempFolderPath+"Raster_MULTIPLY_10.tif")

	NewDataset=SPRasters.Divide(TheDataset,10)
	NewDataset.Save(TempFolderPath+"Raster_DIVIDE_10.tif")

if (True):
	TheDataset=SPRasters.SpaDatasetRaster()
	TheDataset.Load(RasterFilePath)

	TheSampler=SPRasters.SPResample()

	# resize the raster
	NewDataset=TheSampler.Scale(TheDataset,0.2) # really fast
	NewDataset.Save(TempFolderPath+"Zoomed.tif")

	# this is really slow
	#NewDataset=SPRasters.TheSampler.NearestNeighbor(TheDataset) # slow
	#NewDataset.Save("C:/Temp/Sampled.tif")

	# extract a portion of the raster
	#NewDataset=SPRasters.TheSampler.Extract(TheDataset,1500,700,3000,1500) # really fast
	NewDataset1=TheSampler.ExtractByPixels(TheDataset,15,30,30,100) # really fast
	NewDataset1.Save(TempFolderPath+"Extraction.tif")

#Test Comparison Operators
if (True):
	RasterFile2 = SPRasters.LessThan(RasterFilePath,5)
	NewDataset=SPRasters.LessThan(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"LessThan.tif")

	NewDataset=SPRasters.GreaterThan(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"GreaterThan.tif")

	NewDataset=SPRasters.LessThanOrEqual(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"LessThanOrEqual.tif")

	NewDataset=SPRasters.GreaterThanOrEqual(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"GreaterThanOrEqual.tif")

	NewDataset=SPRasters.Equal(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"Equal.tif")

	NewDataset=SPRasters.Maximum(RasterFilePath, RasterFile2)
	NewDataset.Save(TempFolderPath + "Maximum.tif")

	NewDataset=SPRasters.Minimum(RasterFilePath, RasterFile2)
	NewDataset.Save(TempFolderPath + "Minimum.tif")


#Test Arthmetic Operator
if (True):

	RasterFile2 = SPRasters.LessThan(RasterFilePath,5)
	NewDataset=SPRasters.Add(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"Add.tif")
	NewDataset=SPRasters.Add(RasterFilePath,2)
	NewDataset.Save(TempFolderPath+"Add1.tif")
	NewDataset=SPRasters.Add(2,RasterFilePath)
	NewDataset.Save(TempFolderPath+"Add2.tif")

	NewDataset=SPRasters.Subtract(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"Subtract.tif")
	NewDataset=SPRasters.Subtract(RasterFilePath,2)
	NewDataset.Save(TempFolderPath+"Subtract1.tif")
	NewDataset=SPRasters.Subtract(1,RasterFile2)
	NewDataset.Save(TempFolderPath+"Subtract2.tif")

	NewDataset=SPRasters.Divide(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"divide.tif")
	NewDataset=SPRasters.Divide(RasterFilePath,3)
	NewDataset.Save(TempFolderPath+"divide1.tif")
	NewDataset=SPRasters.Divide(1,RasterFile2)
	NewDataset.Save(TempFolderPath+"divide2.tif")


	NewDataset=SPRasters.Multiply(RasterFilePath,RasterFile2)
	NewDataset.Save(TempFolderPath+"Multiple.tif")
	NewDataset=SPRasters.Multiply(RasterFilePath,3)
	NewDataset.Save(TempFolderPath+"Multiple1.tif")
	NewDataset=SPRasters.Multiply(1.0,RasterFile2)
	NewDataset.Save(TempFolderPath+"Multiple2.tif")

#Test Logical Operators
if (True):
	#create some boolean rasters to work with
	RasterFile2 = SPRasters.LessThan(RasterFilePath,5)
	BoolRaster1=SPRasters.GreaterThan(RasterFilePath,RasterFile2)
	BoolRaster2=SPRasters.LessThan(RasterFilePath,RasterFile2)

	NewDataset=SPRasters.And(BoolRaster1,BoolRaster2)
	NewDataset.Save(TempFolderPath + "And.tif")

	NewDataset=SPRasters.Or(BoolRaster1,BoolRaster2)
	NewDataset.Save(TempFolderPath + "Or.tif")

	NewDataset=SPRasters.Not(BoolRaster1)
	NewDataset.Save(TempFolderPath + "Not.tif")

#Test Rounding Functions:
if (True):
	#create a raster with decimal numbers
	DecimalRaster=SPRasters.Divide(RasterFilePath,RasterFile2)
	DecimalRaster.Save(TempFolderPath + "Divide.tif")

	NewDataset=SPRasters.Round(DecimalRaster, 1)
	NewDataset.Save(TempFolderPath + "Round.tif")

	NewDataset=SPRasters.RoundInteger(DecimalRaster)
	NewDataset.Save(TempFolderPath + "Int.Tif")

	NewDataset=SPRasters.RoundFix(DecimalRaster)
	NewDataset.Save(TempFolderPath + "Fix.tif")

	NewDataset=SPRasters.RoundFloor(DecimalRaster)
	NewDataset.Save(TempFolderPath + "Floor.tif")

	NewDataset=SPRasters.RoundCeiling(DecimalRaster)
	NewDataset.Save(TempFolderPath + "Ceiling.tif")

	NewDataset=SPRasters.Truncate(DecimalRaster)
	NewDataset.Save(TempFolderPath + "Truncate.tif")

#test other math function

if (True):

	NewDataset=SPRasters.NaturalLog(RasterFilePath)
	NewDataset.Save(TempFolderPath + "NatLog.tif")

	NewDataset=SPRasters.Log(RasterFilePath)
	NewDataset.Save(TempFolderPath + "Log.tif")

	NewDataset=SPRasters.Exponential(RasterFilePath)
	NewDataset.Save(TempFolderPath + "Exponential.tif")

	NewDataset=SPRasters.Power(RasterFilePath, 2)
	NewDataset.Save(TempFolderPath + "Power.tif")

	NewDataset=SPRasters.Square(RasterFilePath)
	NewDataset.Save(TempFolderPath + "Square.tif")

	NewDataset=SPRasters.SquareRoot(RasterFilePath)
	NewDataset.Save(TempFolderPath + "SquareRoot.tif")

	NewDataset=SPRasters.AbsoluteValue(RasterFilePath)
	NewDataset.Save(TempFolderPath + "Abs.tif")


#test resampler

if (True):
	NewDataset=SPRasters.Resample(RasterFilePath,0.5)
	NewDataset.Save(TempFolderPath + "Resampled.tif")

#test reclassify
if (True):
	NewDataset=SPRasters.ReclassifyRange(RasterFilePath,[(-1000,1),(1,3),(3,10000)],[1,2,3])
	NewDataset.Save(TempFolderPath + "Reclassed.tif")


#test crop
if (True):
	print("*** Performing crop tests")
	NewDataset=SPRasters.Crop(RasterFilePath,[543826,4257679,543924,4257589])
	NewDataset.Save(TempFolderPath+"Cropped.tif")

	NewDataset=SPRasters.NumpyCrop(RasterFilePath,[543826,4257679,543924,4257589])
	NewDataset.Save(TempFolderPath+"NumpyCropped.tif")

if (True):
	NewDataset=SPRasters.Polygonize(RasterFilePath)
	NewDataset.Save(TempFolderPath + "Polygonize.shp")

# topographic transforms
if (True):
	print("*** Performing topography tests")
	NewDataset=SpaTopographicTransforms.Hillshade(RasterFilePath)
	NewDataset.Save(TempFolderPath+"Hillshade.tif")

	NewDataset=SpaTopographicTransforms.Slope(RasterFilePath)
	NewDataset.Save(TempFolderPath+"Slope.tif")

	NewDataset=SpaTopographicTransforms.Aspect(RasterFilePath)
	NewDataset.Save(TempFolderPath+"Aspect.tif")

print("DONE")
