"""
Nicholas Klein-Baer
Created 3/15/19
Updated 3/26/19
Assignment 8 - Part 1
Batch Processing lidar data w/ arcpy
"""

#dependencies
import SPRasters
import os

InputPath = "../Data/"
OutputPath = "../Temp/"

List=os.listdir(InputPath)

for File in List:
    #FileName, FileExtension = os.path.split(File) #for some reason os.path.split is not working here in 3.6.1 ...
    try:
        FileName, FileExtension = File.split(".")
    except:
        continue

    InputFilePath = InputPath + FileName + "." + FileExtension
    print(InputFilePath)
    if (FileExtension == "tif"):
            print("Found a file to process:" + InputFilePath)
            
            Reclass = SPRasters.ReclassifyRange(InputFilePath,[(-1000,1),(1,3),(3,10000)],[1,2,3])
            Reclass.Save(OutputPath + "{0}Reclass.tif".format(FileName))
            Grass = SPRasters.LessThan(InputFilePath,1)
            Grass.Save(OutputPath + "{0}Grass.tif".format(FileName))
            
            Trees = SPRasters.GreaterThan(InputFilePath,4)
            Trees.Save(OutputPath + "{0}Trees.tif".format(FileName))
            
            #No Boolean functions, so this is a little work around
            NotGrass = SPRasters.GreaterThan(InputFilePath,1)
            NotTrees = SPRasters.LessThan(InputFilePath,4)
            Shrubs = SPRasters.Multiply(NotGrass,NotTrees)
            Shrubs.Save(OutputPath + "{0}Shrubs.tif".format(FileName))
            
            ShrubClass = SPRasters.Multiply(Shrubs, 2)
            ShrubClass.Save(OutputPath + "{0}ShrubClass.tif".format(FileName))
            OtherShrubClass = SPRasters.ReclassifyDiscrete(Shrubs,[0,1],[0,2])
            OtherShrubClass.Save(OutputPath + "{0}OtherShrubClass.tif".format(FileName))
            
            TreeClass = SPRasters.Multiply(Trees,3)
            TreeClass.Save(OutputPath + "{0}TreeClass.tif".format(FileName))
            
            ClassRaster = SPRasters.Add(Grass,TreeClass)
            ClassRaster = SPRasters.Add(ClassRaster,ShrubClass)
            ClassRaster.Save(OutputPath + "{0}ClassRaster.tif".format(FileName))
            
           
            ResampleRaster = SPRasters.Resample(ClassRaster, 1/30)
            ResampleRaster.Save(OutputPath + "{0}ResampleRaster.tif".format(FileName))
         
            ResampleRaster = SPRasters.SpaDatasetRaster()
            ResampleRaster.Load(OutputPath + "{0}ResampleRaster.tif".format(FileName))
            ResampleRaster.Polygonize(OutputPath+"{0}PolygonizedRaster.tif".format(FileName))
           